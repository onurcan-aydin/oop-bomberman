package de.tum.cit.ase.bomberquest.texture;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

/**
 * Contains all animation constants used in the game.
 * It is good practice to keep all textures and animations in constants to avoid loading them multiple times.
 * These can be referenced anywhere they are needed.
 */
public class Animations {

    /**
     * The animation for the character walking down.
     */
    public static final Animation<TextureRegion> CHARACTER_WALK_DOWN = new Animation<>(0.1f,
            SpriteSheet.CHARACTER.at(1, 1),
            SpriteSheet.CHARACTER.at(1, 2),
            SpriteSheet.CHARACTER.at(1, 3),
            SpriteSheet.CHARACTER.at(1, 4)
    );

    /**
     * The animation for the character walking up.
     */
    public static final Animation<TextureRegion> CHARACTER_WALK_UP = new Animation<>(0.1f,
            SpriteSheet.CHARACTER.at(3, 1),
            SpriteSheet.CHARACTER.at(3, 2),
            SpriteSheet.CHARACTER.at(3, 3),
            SpriteSheet.CHARACTER.at(3, 4)
    );

    /**
     * The animation for the character walking left.
     */
    public static final Animation<TextureRegion> CHARACTER_WALK_LEFT = new Animation<>(0.1f,
            SpriteSheet.CHARACTER.at(4, 1),
            SpriteSheet.CHARACTER.at(4, 2),
            SpriteSheet.CHARACTER.at(4, 3),
            SpriteSheet.CHARACTER.at(4, 4)
    );

    /**
     * The animation for the character walking right.
     */
    public static final Animation<TextureRegion> CHARACTER_WALK_RIGHT = new Animation<>(0.1f,
            SpriteSheet.CHARACTER.at(2, 1),
            SpriteSheet.CHARACTER.at(2, 2),
            SpriteSheet.CHARACTER.at(2, 3),
            SpriteSheet.CHARACTER.at(2, 4)
    );

    /**
     * The animation for the character idle.
     * Assuming the idle animation is just the first frame of walking down.
     */
    public static final Animation<TextureRegion> CHARACTER_IDLE = new Animation<>(0.1f,
            SpriteSheet.CHARACTER.at(1, 1),
            SpriteSheet.CHARACTER.at(1, 2),
            SpriteSheet.CHARACTER.at(1, 3),
            SpriteSheet.CHARACTER.at(1, 4)
    );

    public static final Animation<TextureRegion> BOMB = new Animation<>(0.1f,
            SpriteSheet.ORIGINAL_BOMBERMAN.at(4, 1),
            SpriteSheet.ORIGINAL_BOMBERMAN.at(4, 2),
            SpriteSheet.ORIGINAL_BOMBERMAN.at(4, 3),
            SpriteSheet.ORIGINAL_BOMBERMAN.at(4, 2),
            SpriteSheet.ORIGINAL_BOMBERMAN.at(4, 1)

    );

    public static final Animation<TextureRegion> CONCURRENTBOMBPOWERUP = new Animation<>(0.3f,
            SpriteSheet.THINGS.at(7, 4),
            SpriteSheet.THINGS.at(7, 5),
            SpriteSheet.THINGS.at(7, 6),
            SpriteSheet.THINGS.at(7, 5),
            SpriteSheet.THINGS.at(7, 4)

    );

    public static final Animation<TextureRegion> BLAST_RADIUS_POWERUP = new Animation<>(0.3f,
            SpriteSheet.OBJECTS.at(4, 5),
            SpriteSheet.OBJECTS.at(4, 6),
            SpriteSheet.OBJECTS.at(4, 7),
            SpriteSheet.OBJECTS.at(4, 8),
            SpriteSheet.OBJECTS.at(4, 7),
            SpriteSheet.OBJECTS.at(4, 6),
            SpriteSheet.OBJECTS.at(4, 5)
    );

    public static final Animation<TextureRegion> ENEMY_ANIMATION_IDLE = new Animation<>(0.3f,
            SpriteSheet.MOBS.at(1, 1),
            SpriteSheet.MOBS.at(1, 2),
            SpriteSheet.MOBS.at(1, 3),
            SpriteSheet.MOBS.at(1, 2),
            SpriteSheet.MOBS.at(1, 1)
            );


}

