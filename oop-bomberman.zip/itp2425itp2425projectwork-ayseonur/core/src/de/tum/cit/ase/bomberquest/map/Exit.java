package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

/**
 * Represents the exit point of the game map.
 *
 * The exit is a fixed location that the player must reach to win the game.
 * It is initially locked and can be unlocked under certain conditions (e.g., defeating all enemies).
 */
public class Exit implements Drawable {
    private final float x; // X-coordinate of the exit
    private final float y; // Y-coordinate of the exit

    /**
     * Constructs an exit at the specified location.
     *
     * @param x The x-coordinate of the exit.
     * @param y The y-coordinate of the exit.
     */
    public Exit(float x, float y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Returns the texture representing the exit.
     *
     * @return The exit texture.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        return Textures.EXIT;
    }

    /**
     * Returns the x-coordinate of the exit.
     *
     * @return The x-coordinate.
     */
    @Override
    public float getX() {
        return x;
    }

    /**
     * Returns the y-coordinate of the exit.
     *
     * @return The y-coordinate.
     */
    @Override
    public float getY() {
        return y;
    }
}
