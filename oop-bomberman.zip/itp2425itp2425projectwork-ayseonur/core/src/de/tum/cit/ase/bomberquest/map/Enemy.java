package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import de.tum.cit.ase.bomberquest.texture.Animations;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

import java.util.Random;

/**
 * Represents an enemy in the game.
 *
 * The enemy moves randomly within the map and can collide with walls.
 * If it encounters a player, a collision is registered.
 */
public class Enemy implements Drawable {
    private float x; // Enemy's x-coordinate on the map
    private float y; // Enemy's y-coordinate on the map

    private final Random random = new Random(); // For generating random movements
    private float moveTimer = 0; // Timer for controlling movement frequency

    // Last movement direction: 0 = up, 1 = down, 2 = left, 3 = right
    private int lastDirection = -1;
    private float delta = 1f; // Movement step size
    private float elapsedTime; // Tracks animation time

    /**
     * Creates an enemy at the specified location.
     *
     * @param x The initial x-coordinate of the enemy.
     * @param y The initial y-coordinate of the enemy.
     */
    public Enemy(float x, float y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Returns the current appearance of the enemy.
     *
     * @return A texture region representing the enemy animation.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        return Animations.ENEMY_ANIMATION_IDLE.getKeyFrame(this.elapsedTime, true);
    }

    /**
     * Returns the enemy's current x-coordinate.
     *
     * @return The x-coordinate of the enemy.
     */
    @Override
    public float getX() {
        return x;
    }

    /**
     * Returns the enemy's current y-coordinate.
     *
     * @return The y-coordinate of the enemy.
     */
    @Override
    public float getY() {
        return y;
    }

    /**
     * Updates the enemy's position based on random movement, ensuring it does not collide with walls.
     *
     * @param frameTime The time since the last frame (used for movement timing).
     * @param gameMap The game map, used for collision and boundary checks.
     */
    public void tick(float frameTime, GameMap gameMap) {
        this.elapsedTime += frameTime;
        moveTimer += frameTime;

        // Move the enemy every 0.5 seconds
        if (moveTimer >= 0.5f) {
            moveTimer = 0;

            // Randomly choose a direction or continue the last direction
            int direction = random.nextInt(4);
            float newX = x;
            float newY = y;
            switch (direction) {
                case 0: // Up
                    newY += delta;
                    break;
                case 1: // Down
                    newY -= delta;
                    break;
                case 2: // Left
                    newX -= delta;
                    break;
                case 3: // Right
                    newX += delta;
                    break;
            }

            // Check if the new position collides with a wall
            if (gameMap.isIndestructibleWallAt(newX, newY) || gameMap.isDestructibleWallAt(newX, newY)) {
                // Reverse direction if the enemy would hit a wall
                switch (direction) {
                    case 0: // Up
                        newY -= delta;
                        break;
                    case 1: // Down
                        newY += delta;
                        break;
                    case 2: // Left
                        newX += delta;
                        break;
                    case 3: // Right
                        newX -= delta;
                        break;
                }
            } else {
                // Move the enemy if no wall is blocking the path
                this.x = newX;
                this.y = newY;
            }

            // Store the last movement direction
            lastDirection = direction;
        }
    }

    /**
     * Checks if the enemy collides with the player.
     *
     * @param player The player object.
     * @return True if the enemy collides with the player, false otherwise.
     */
    public boolean collidesWithPlayer(Player player) {
        boolean collision = Math.round(this.x) == Math.round(player.getX()) &&
                Math.round(this.y) == Math.round(player.getY());

        if (collision) {
            System.out.println("Collision detected! Enemy at (" + this.x + ", " + this.y +
                    ") collided with Player at (" + player.getX() + ", " + player.getY() + ")");
        }

        return collision;
    }
}
