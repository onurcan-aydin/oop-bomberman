package de.tum.cit.ase.bomberquest.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.ScreenUtils;
import de.tum.cit.ase.bomberquest.BomberQuestGame;
import de.tum.cit.ase.bomberquest.map.*;
import de.tum.cit.ase.bomberquest.texture.Drawable;

/**
 * The GameScreen class is responsible for rendering the gameplay screen.
 * It handles the game logic and rendering of the game elements.
 */
public class GameScreen implements Screen {

    /** The size of a grid cell in pixels, used for coordinate scaling. */
    public static final int TILE_SIZE_PX = 16;

    /** The scale factor for making everything in the game look bigger or smaller. */
    public static final int SCALE = 4;

    private final BomberQuestGame game; // Reference to the game
    private final SpriteBatch spriteBatch; // SpriteBatch used for rendering
    private final GameMap map; // Reference to the game map
    private final Hud hud; // Reference to the HUD
    private final OrthographicCamera mapCamera; // Camera to view the map

    private final CountdownTimer countdownTimer; // Countdown timer for the game

    /**
     * Constructor for GameScreen. Sets up the camera and font.
     *
     * @param game The main game class, used to access global resources and methods.
     */
    public GameScreen(BomberQuestGame game) {
        this.game = game;
        this.spriteBatch = game.getSpriteBatch();
        this.map = game.getMap();
        this.mapCamera = new OrthographicCamera();
        this.mapCamera.setToOrtho(false);
        this.countdownTimer = new CountdownTimer(300); // Initialize with a 5-minute timer
        this.countdownTimer.setListener(() -> game.getMap().handleCountdownEnd()); // Listener for when the timer ends

        this.hud = new Hud(spriteBatch, game.getSkin().getFont("font"), countdownTimer, map.getPlayer(), map);
        map.setHud(this.hud); // Set HUD for the map
    }

    /**
     * Handles the player win scenario and transitions to the VictoryScreen.
     */
    public void handlePlayerWin() {
        System.out.println("Player has won the game!");
        game.setScreen(new VictoryScreen(game)); // Switch to the VictoryScreen when the player wins
    }

    /**
     * Renders the game every frame.
     * @param deltaTime The time elapsed since the last render.
     */
    @Override
    public void render(float deltaTime) {
        // Check for escape key press to go back to the menu
        if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
            game.goToMenu(true); // Navigate to the main menu
            return;
        }

        if (game.isGameOver()) {
            return; // If the game is over, stop rendering or updating
        }

        // Clear the previous frame
        ScreenUtils.clear(Color.BLACK);

        // Cap frame time to prevent large jumps
        float frameTime = Math.min(deltaTime, 0.250f);

        // Update the map state
        map.tick(frameTime);

        // Update the camera based on the player's position
        updateCamera();

        // Render the map elements
        renderMap();

        // Update the countdown timer
        countdownTimer.update(deltaTime);

        // Render the HUD
        hud.render();
    }

    /**
     * Updates the camera to follow the player and ensures it stays within the map bounds.
     */
    private void updateCamera() {
        Player player = map.getPlayer(); // Get the player from the map

        float playerX = player.getX() * TILE_SIZE_PX * SCALE;
        float playerY = player.getY() * TILE_SIZE_PX * SCALE;

        float cameraHalfWidth = mapCamera.viewportWidth / 2;
        float cameraHalfHeight = mapCamera.viewportHeight / 2;

        // Define a safe zone around the player to prevent jittering
        float safeZoneWidth = mapCamera.viewportWidth * 0.2f; // 20% of the width
        float safeZoneHeight = mapCamera.viewportHeight * 0.2f; // 20% of the height

        // Calculate the boundaries of the safe zone
        float safeZoneLeft = mapCamera.position.x - safeZoneWidth;
        float safeZoneRight = mapCamera.position.x + safeZoneWidth;
        float safeZoneBottom = mapCamera.position.y - safeZoneHeight;
        float safeZoneTop = mapCamera.position.y + safeZoneHeight;

        boolean cameraAdjusted = false;

        // Determine if the map is smaller than the screen, restricting camera movement
        boolean restrictX = map.getWidth() * TILE_SIZE_PX * SCALE <= mapCamera.viewportWidth;
        boolean restrictY = map.getHeight() * TILE_SIZE_PX * SCALE <= mapCamera.viewportHeight;

        // Adjust the camera position if the player is outside the safe zone
        if (!restrictX) {
            if (playerX < safeZoneLeft) {
                mapCamera.position.x -= (safeZoneLeft - playerX);
                cameraAdjusted = true;
            } else if (playerX > safeZoneRight) {
                mapCamera.position.x += (playerX - safeZoneRight);
                cameraAdjusted = true;
            }
        }

        if (!restrictY) {
            if (playerY < safeZoneBottom) {
                mapCamera.position.y -= (safeZoneBottom - playerY);
                cameraAdjusted = true;
            } else if (playerY > safeZoneTop) {
                mapCamera.position.y += (playerY - safeZoneTop);
                cameraAdjusted = true;
            }
        }

        // Clamp the camera position to ensure it stays within the map bounds
        if (cameraAdjusted) {
            if (!restrictX) {
                mapCamera.position.x = MathUtils.clamp(
                        mapCamera.position.x,
                        cameraHalfWidth,
                        map.getWidth() * TILE_SIZE_PX * SCALE - cameraHalfWidth
                );
            }
            if (!restrictY) {
                mapCamera.position.y = MathUtils.clamp(
                        mapCamera.position.y,
                        cameraHalfHeight,
                        map.getHeight() * TILE_SIZE_PX * SCALE - cameraHalfHeight
                );
            }
        }

        // Update the camera only if it was adjusted
        if (cameraAdjusted) {
            mapCamera.update();
        }
    }

    /**
     * Renders the game map by drawing all game objects.
     */
    private void renderMap() {
        spriteBatch.setProjectionMatrix(mapCamera.combined); // Set the projection matrix to the camera's view
        spriteBatch.begin(); // Start drawing

        // Draw all game elements in the correct order (e.g., background first, player last)
        for (Flowers flowers : map.getFlowers()) {
            draw(spriteBatch, flowers);
        }

        for (IndestructibleWall indestructibleWall : map.getInDestructibleWalls()) {
            draw(spriteBatch, indestructibleWall);
        }

        for (ConcurrentBombPowerup concurrentBombPowerup : map.getConcurrentPowerups()) {
            draw(spriteBatch, concurrentBombPowerup);
        }

        for (BlastRadiusPowerup blastRadiusPowerup : map.getBlastRadiusPowerups()) {
            draw(spriteBatch, blastRadiusPowerup);
        }

        draw(spriteBatch, map.getEntrance());
        draw(spriteBatch, map.getExit());

        for (DestructibleWall destructibleWall : map.getDestructibleWalls()) {
            draw(spriteBatch, destructibleWall);
        }

        for (Enemy enemy : map.getEnemies()) {
            draw(spriteBatch, enemy);
        }

        draw(spriteBatch, map.getPlayer()); // Draw the player last
        for (Bomb bomb : map.getBombs()) {
            bomb.render(spriteBatch); // Render the bombs
        }

        spriteBatch.end(); // Finish drawing
    }

    /**
     * Draws a drawable object on the screen with scaling applied.
     * @param spriteBatch The SpriteBatch used for drawing.
     * @param drawable The object to draw.
     */
    private static void draw(SpriteBatch spriteBatch, Drawable drawable) {
        TextureRegion texture = drawable.getCurrentAppearance();
        float x = drawable.getX() * TILE_SIZE_PX * SCALE; // Convert tile coordinates to pixels
        float y = drawable.getY() * TILE_SIZE_PX * SCALE;
        float width = texture.getRegionWidth() * SCALE; // Scale the texture size
        float height = texture.getRegionHeight() * SCALE;
        spriteBatch.draw(texture, x, y, width, height); // Draw the object
    }

    /**
     * Called when the window is resized.
     * Updates the camera and HUD to match the new window size.
     * @param width The new window width.
     * @param height The new window height.
     */
    @Override
    public void resize(int width, int height) {
        mapCamera.setToOrtho(false);
        hud.resize(width, height); // Adjust HUD for new size
    }

    // Unused methods from the Screen interface
    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void show() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {}
}
