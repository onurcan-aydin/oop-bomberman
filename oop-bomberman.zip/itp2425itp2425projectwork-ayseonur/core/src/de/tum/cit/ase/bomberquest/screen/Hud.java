package de.tum.cit.ase.bomberquest.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import de.tum.cit.ase.bomberquest.map.Bomb;
import de.tum.cit.ase.bomberquest.map.GameMap;
import de.tum.cit.ase.bomberquest.map.Player;
import de.tum.cit.ase.bomberquest.map.CountdownTimer;

/**
 * A Heads-Up Display (HUD) that displays information on the screen.
 * It uses a separate camera so that it is always fixed on the screen.
 */
public class Hud {

    /** The SpriteBatch used to draw the HUD. This is the same as the one used in the GameScreen. */
    private final SpriteBatch spriteBatch;

    /** The font used to draw text on the screen. */
    private final BitmapFont font;

    /** The camera used to render the HUD. */
    private final OrthographicCamera camera;

    // HUD data
    private int concurrentBombLimit;    // Current concurrent bomb limit
    private int remainingEnemies;       // Remaining number of enemies
    private boolean allEnemiesDefeated; // Indicator if all enemies are defeated
    private final CountdownTimer countdownTimer; // Countdown timer in seconds

    private final ShapeRenderer shapeRenderer; // For drawing the background rectangle
    private final Player player;

    /**
     * Constructor for HUD. Initializes all necessary components for displaying the HUD.
     *
     * @param spriteBatch The sprite batch used for rendering.
     * @param font The font used to render text.
     * @param countdownTimer The countdown timer to display.
     * @param player The player, to display information about the player.
     * @param gameMap The game map, used to determine the number of enemies.
     */
    public Hud(SpriteBatch spriteBatch, BitmapFont font, CountdownTimer countdownTimer, Player player, GameMap gameMap) {
        this.spriteBatch = spriteBatch;
        this.font = font;
        this.camera = new OrthographicCamera();
        this.camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        this.shapeRenderer = new ShapeRenderer(); // Initialize ShapeRenderer for the HUD background

        // Initialize HUD data
        this.concurrentBombLimit = 1;  // Default concurrent bombs
        this.countdownTimer = countdownTimer;
        this.player = player;
        this.remainingEnemies = gameMap.getEnemies().size(); // Get the initial number of enemies
        this.allEnemiesDefeated = false;  // Default defeated status
    }

    /**
     * Renders the HUD on the screen.
     * This uses a different OrthographicCamera so that the HUD is always fixed on the screen.
     */
    public void render() {
        // Set up the camera for the HUD
        spriteBatch.setProjectionMatrix(camera.combined);
        shapeRenderer.setProjectionMatrix(camera.combined);

        // Draw a semi-transparent black rectangle as the HUD background
        Gdx.gl.glEnable(GL20.GL_BLEND);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(0, 0, 0, 0.5f); // Black with 50% transparency
        shapeRenderer.rect(5, Gdx.graphics.getHeight() - 155, 350, 145); // Draw the background rectangle
        shapeRenderer.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);

        // Draw the HUD text
        spriteBatch.begin();
        font.draw(spriteBatch, "Press Esc to Pause!", 10, Gdx.graphics.getHeight() - 10);
        font.draw(spriteBatch, "Blast Radius: " + Bomb.getBlastRadius(), 10, Gdx.graphics.getHeight() - 40); // Dynamically fetch blast radius
        font.draw(spriteBatch, "Bomb Limit: " + player.getConcurrentBombLimit(), 10, Gdx.graphics.getHeight() - 70);
        font.draw(spriteBatch, "Timer: " + formatTime(countdownTimer.getTimeRemaining()), 10, Gdx.graphics.getHeight() - 100); // Display timer in mm:ss format
        font.draw(spriteBatch, "Enemies Left: " + remainingEnemies, 10, Gdx.graphics.getHeight() - 130); // Display remaining enemies
        if (allEnemiesDefeated) {
            font.draw(spriteBatch, "All Enemies Defeated! Exit Unlocked!", 10, Gdx.graphics.getHeight() - 160); // Message when all enemies are defeated
        }
        spriteBatch.end();
    }

    /**
     * Resizes the HUD when the screen size changes.
     * This is called when the window is resized.
     * @param width The new width of the screen.
     * @param height The new height of the screen.
     */
    public void resize(int width, int height) {
        camera.setToOrtho(false, width, height); // Adjust the HUD camera to the new screen size
    }

    /**
     * Formats the time as mm:ss.
     * @param timeInSeconds The time in seconds to format.
     * @return The formatted time as a string in mm:ss format.
     */
    private String formatTime(float timeInSeconds) {
        int minutes = (int) (timeInSeconds / 60); // Get the minutes part
        int seconds = (int) (timeInSeconds % 60); // Get the seconds part
        return String.format("%02d:%02d", minutes, seconds); // Format and return the time
    }

    // Update methods for the HUD data

    /**
     * Sets the concurrent bomb limit.
     * @param concurrentBombLimit The new limit for concurrent bombs.
     */
    public void setConcurrentBombLimit(int concurrentBombLimit) {
        this.concurrentBombLimit = concurrentBombLimit;
    }

    /**
     * Updates the number of remaining enemies and checks if all enemies are defeated.
     * @param remainingEnemies The number of enemies remaining.
     */
    public void setRemainingEnemies(int remainingEnemies) {
        this.remainingEnemies = remainingEnemies;
        this.allEnemiesDefeated = remainingEnemies <= 0; // Update the "all enemies defeated" status
    }

    /**
     * Checks if all enemies have been defeated.
     * @return True if all enemies are defeated, false otherwise.
     */
    public boolean isAllEnemiesDefeated() {
        return allEnemiesDefeated;
    }
}
