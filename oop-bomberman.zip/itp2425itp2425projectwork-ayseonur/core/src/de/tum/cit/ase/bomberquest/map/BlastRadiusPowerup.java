package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import de.tum.cit.ase.bomberquest.texture.Animations;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

/**
 * Represents a power-up that increases the blast radius of bombs when collected by the player.
 * This class extends {@link Powerup} and implements {@link Drawable} to be rendered on the map.
 */
public class BlastRadiusPowerup extends Powerup implements Drawable {

    /** Tracks the elapsed time to animate the power-up. */
    private float elapsedTime;

    /**
     * Constructs a BlastRadiusPowerup at the specified coordinates.
     *
     * @param x The x-coordinate of the power-up in the game world.
     * @param y The y-coordinate of the power-up in the game world.
     */
    public BlastRadiusPowerup(float x, float y) {
        super(x, y);
    }

    /**
     * Retrieves the current appearance of the power-up based on animation.
     * The texture is updated based on the elapsed animation time.
     *
     * @return The current frame of the blast radius power-up animation.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        return Animations.BLAST_RADIUS_POWERUP.getKeyFrame(this.elapsedTime, true);
    }

    /**
     * Updates the animation state of the power-up.
     * This method is called every frame to progress the animation.
     *
     * @param frameTime The time elapsed since the last frame, used to update animation timing.
     */
    public void tick(float frameTime) {
        this.elapsedTime += frameTime;
    }
}
