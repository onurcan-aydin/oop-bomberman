package de.tum.cit.ase.bomberquest.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import de.tum.cit.ase.bomberquest.BomberQuestGame;

/**
 * The MenuScreen class is responsible for displaying the main menu of the game.
 * It extends the LibGDX Screen class and sets up the UI components for the menu.
 */
public class MenuScreen implements Screen {
    private final Stage stage; // Stage to hold all UI components
    private final BomberQuestGame game; // Reference to the main game class

    /**
     * Constructor to initialize the menu screen.
     * @param game The main game class.
     * @param isPaused Indicates whether the game is paused, affecting the menu options.
     */
    public MenuScreen(BomberQuestGame game, boolean isPaused) {
        this.game = game;
        OrthographicCamera camera = new OrthographicCamera(); // Camera to render the UI
        camera.setToOrtho(false);
        ScreenViewport viewport = new ScreenViewport(camera); // Viewport for the camera
        stage = new Stage(viewport, game.getSpriteBatch()); // Stage to manage UI components

        Table table = new Table(); // Table to organize UI components
        table.setFillParent(true); // Make the table fill the screen
        stage.addActor(table); // Add the table to the stage

        Label titleLabel = new Label("Game Menu", game.getSkin(), "title"); // Menu title
        titleLabel.setColor(Color.WHITE); // Set title text color to white
        table.add(titleLabel).padBottom(80).row(); // Add title to the table

        if (isPaused) { // If the game is paused, add the continue button
            TextButton continueButton = new TextButton("Continue", game.getSkin());
            continueButton.addListener(new ChangeListener() {
                @Override
                public void changed(ChangeEvent event, Actor actor) {
                    game.goToGame(); // Resume the game
                }
            });
            table.add(continueButton).width(300).padBottom(20).row(); // Add continue button to table
        }

        // Add "Choose New Map" button
        TextButton newMapButton = new TextButton("Choose New Map", game.getSkin());
        newMapButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.loadMapFromFile(); // Open file chooser to select a new map

                // After selecting a map, reset the game with the chosen map
                Gdx.app.postRunnable(() -> {
                    String selectedMapPath = game.getSelectedMapPath();
                    if (selectedMapPath != null) {
                        game.resetGame(selectedMapPath); // Reset the game with the selected map
                    } else {
                        Gdx.app.log("MenuScreen", "No valid map selected."); // Log if no map is selected
                    }
                });
            }
        });
        table.add(newMapButton).width(300).padBottom(20).row(); // Add new map button to table

        // Add "Exit" button
        TextButton exitButton = new TextButton("Exit", game.getSkin());
        exitButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                Gdx.app.exit(); // Exit the game when the exit button is pressed
            }
        });
        table.add(exitButton).width(300).row(); // Add exit button to table
    }

    /**
     * Renders the menu screen.
     * @param deltaTime Time since the last render call.
     */
    @Override
    public void render(float deltaTime) {
        ScreenUtils.clear(Color.BLACK); // Clear the screen with black color
        stage.act(deltaTime); // Update the stage
        stage.draw(); // Draw all the UI components
    }

    /**
     * Resizes the viewport when the window size changes.
     * @param width The new width of the screen.
     * @param height The new height of the screen.
     */
    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true); // Update the stage's viewport
    }

    /**
     * Disposes of the resources used by the menu screen.
     */
    @Override
    public void dispose() {
        stage.dispose(); // Dispose of the stage when it's no longer needed
    }

    /**
     * Sets the input processor to the stage for handling user input.
     */
    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage); // Set the input processor to handle button clicks
    }

    // Unused methods from the Screen interface
    @Override
    public void hide() {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}
}
