package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

/**
 * Represents a power-up in the game.
 * This power-up can be collected by the player.
 */
public class Powerup implements Drawable {

    private final float x; // The x-coordinate of the power-up
    private final float y; // The y-coordinate of the power-up

    /**
     * Constructor to create a power-up at a specific position.
     * @param x The x-coordinate of the power-up.
     * @param y The y-coordinate of the power-up.
     */
    public Powerup(float x, float y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Gets the current appearance of the power-up.
     * @return The texture of the concurrent bomb power-up.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        return Textures.CONCURRENT_BOMB_POWERUP; // Return the texture for the concurrent bomb power-up
    }

    /**
     * Gets the x-coordinate of the power-up.
     * @return The x-coordinate of the power-up.
     */
    @Override
    public float getX() {
        return x;
    }

    /**
     * Gets the y-coordinate of the power-up.
     * @return The y-coordinate of the power-up.
     */
    @Override
    public float getY() {
        return y;
    }
}
