package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.*;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

/**
 * Represents an indestructible wall in the game.
 *
 * This type of wall acts as a permanent obstacle that cannot be destroyed.
 * It extends the Wall class and implements the Drawable interface to provide
 * a texture for rendering.
 */
public class IndestructibleWall extends Wall implements Drawable {

    /**
     * Constructs an IndestructibleWall at a specified position.
     *
     * @param world The Box2D physics world.
     * @param x The x-coordinate of the wall.
     * @param y The y-coordinate of the wall.
     */
    public IndestructibleWall(World world, float x, float y) {
        super(world, x, y); // Calls the parent Wall constructor to initialize the wall.
    }

    /**
     * Retrieves the texture appearance of the indestructible wall.
     *
     * @return The TextureRegion representing the wall.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        return Textures.INDESTRUCTIBLE_WALL; // Returns the indestructible wall texture.
    }
}
