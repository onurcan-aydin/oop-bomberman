package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

/**
 * Represents a wall in the game.
 * This wall can be interacted with by the player or destroyed in the future.
 */
public class Wall implements Drawable {
    private final float x; // The x-coordinate of the wall
    private final float y; // The y-coordinate of the wall
    private Body body; // The Box2D body associated with the wall

    /**
     * Constructor to create a wall at a specific position in the world.
     * @param world The Box2D world to add the body to.
     * @param x The x-coordinate of the wall.
     * @param y The y-coordinate of the wall.
     */
    public Wall(World world, float x, float y) {
        this.x = x;
        this.y = y;
        this.body = createHitbox(world); // Create the Box2D body for the wall
    }

    /**
     * Creates a Box2D body for the wall.
     * @param world The Box2D world to add the body to.
     * @return The created body.
     */
    private Body createHitbox(World world) {
        // BodyDef defines properties for the body (position, type).
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.StaticBody; // Static body, won't move
        bodyDef.position.set(this.x, this.y); // Set the initial position

        // Create the body in the world.
        Body body = world.createBody(bodyDef);

        // Define the shape for the wall (polygon).
        PolygonShape box = new PolygonShape();
        box.setAsBox(0.5f, 0.5f); // Set the size of the wall (0.5 x 0.5 tiles)

        // Attach the shape to the body as a fixture.
        body.createFixture(box, 1.0f); // Set the fixture with a density of 1.0
        box.dispose(); // Dispose of the shape after use

        // Set the wall as the user data for this body.
        body.setUserData(this);
        return body;
    }

    /**
     * Gets the current appearance of the wall.
     * @return The texture of the destructible wall.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        return Textures.DESTRUCTIBLE_WALL; // Return the texture for the destructible wall
    }

    /**
     * Gets the x-coordinate of the wall.
     * @return The x-coordinate of the wall.
     */
    @Override
    public float getX() {
        return x;
    }

    /**
     * Gets the y-coordinate of the wall.
     * @return The y-coordinate of the wall.
     */
    @Override
    public float getY() {
        return y;
    }

    /**
     * Gets the Box2D body associated with the wall.
     * @return The body of the wall.
     */
    public Body getBody() {
        return body;
    }
}
