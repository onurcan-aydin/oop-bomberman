package de.tum.cit.ase.bomberquest.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import de.tum.cit.ase.bomberquest.BomberQuestGame;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;


/**
 * The VictoryScreen class displays the victory screen after the player wins the game.
 * It includes a victory message and buttons to either return to the main menu or play again.
 */
public class VictoryScreen implements com.badlogic.gdx.Screen {
    private final BomberQuestGame game; // Reference to the game
    private final Stage stage; // Stage for UI elements
    private final BitmapFont font; // Font used for text rendering

    private Sound winSound; // Sound played when the player wins

    /**
     * Constructor for VictoryScreen. Initializes the UI components and plays the victory sound.
     * @param game The main game class, used to access global resources and methods.
     */
    public VictoryScreen(BomberQuestGame game) {
        this.game = game;

        // Set up the camera and stage for rendering the UI
        OrthographicCamera camera = new OrthographicCamera();
        camera.setToOrtho(false); // Set the camera to orthogonal projection
        stage = new Stage(new ScreenViewport(camera), game.getSpriteBatch()); // Stage to manage UI components
        Gdx.input.setInputProcessor(stage); // Set input processor to handle button clicks

        // Set up font for displaying text
        font = new BitmapFont(); // Initialize the font
        font.getData().setScale(2); // Scale the font size
        font.setColor(Color.GREEN); // Set font color to green

        // Load and play the victory sound
        this.winSound = game.getAssetManager().get("audio/victory.mp3", Sound.class);
        winSound.play(); // Play the victory sound

        // Create a layout table for organizing UI components
        Table table = new Table();
        table.setFillParent(true); // Make the table fill the screen
        stage.addActor(table); // Add the table to the stage

        // Add a victory message to the table
        Label victoryLabel = new Label("Victory! You Won!", game.getSkin(), "title");
        victoryLabel.setColor(Color.GOLD); // Set the victory message color to gold
        victoryLabel.getColor().a = 0; // Start with the label fully transparent
        victoryLabel.addAction(Actions.fadeIn(2f)); // Fade in the label over 2 seconds
        table.add(victoryLabel).padBottom(40).row(); // Add label to the table

        // Add a button to go back to the main menu
        TextButton mainMenuButton = new TextButton("Return to Main Menu", game.getSkin());
        mainMenuButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.goToMenu(false); // Navigate to the main menu when pressed
            }
        });
        table.add(mainMenuButton).width(400).padBottom(20).row(); // Add button to table

        // Add a button to play the game again
        TextButton playAgainButton = new TextButton("Play Again", game.getSkin());
        playAgainButton.addAction(Actions.forever(Actions.sequence(
                Actions.scaleTo(1.2f, 1.2f, 0.5f), // Scale the button up
                Actions.scaleTo(1f, 1f, 0.5f) // Scale it back down
        )));
        playAgainButton.addListener(event -> {
            if (playAgainButton.isPressed()) {
                game.goToGame(); // Restart the game when the button is pressed
                return true;
            }
            return false;
        });
        table.add(playAgainButton).width(400).row(); // Add button to table
    }

    /**
     * Renders the victory screen.
     * @param deltaTime The time elapsed since the last frame.
     */
    @Override
    public void render(float deltaTime) {
        // Clear the screen with a black background
        ScreenUtils.clear(Color.BLACK);

        // Update and draw the stage
        stage.act(deltaTime);
        stage.draw();
    }

    /**
     * Resizes the stage when the window size changes.
     * @param width The new width of the screen.
     * @param height The new height of the screen.
     */
    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true); // Update the stage viewport
    }

    /**
     * Called when the screen is shown. Not used in this case.
     */
    @Override
    public void show() {}

    /**
     * Called when the screen is hidden. Not used in this case.
     */
    @Override
    public void hide() {}

    /**
     * Called when the game is paused. Not used in this case.
     */
    @Override
    public void pause() {}

    /**
     * Called when the game is resumed. Not used in this case.
     */
    @Override
    public void resume() {}

    /**
     * Disposes of the resources used by the victory screen.
     */
    @Override
    public void dispose() {
        font.dispose(); // Dispose of the font resource
    }
}
