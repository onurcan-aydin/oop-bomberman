package de.tum.cit.ase.bomberquest;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import de.tum.cit.ase.bomberquest.audio.MusicTrack;
import de.tum.cit.ase.bomberquest.map.Bomb;
import de.tum.cit.ase.bomberquest.map.CountdownTimer;
import de.tum.cit.ase.bomberquest.map.GameMap;
import de.tum.cit.ase.bomberquest.screen.GameOverScreen;
import de.tum.cit.ase.bomberquest.screen.GameScreen;
import de.tum.cit.ase.bomberquest.screen.MenuScreen;
import games.spooky.gdx.nativefilechooser.NativeFileChooser;
import games.spooky.gdx.nativefilechooser.NativeFileChooserConfiguration;
import games.spooky.gdx.nativefilechooser.NativeFileChooserCallback;

import java.io.File;

/**
 * The BomberQuestGame class represents the core of the Bomber Quest game.
 * It manages the screens and global resources like SpriteBatch and Skin.
 */
public class BomberQuestGame extends Game {
    private AssetManager assetManager; // Manages loading and accessing assets
    private GameScreen gameScreen; // Game screen to be shown
    private MenuScreen menuScreen; // Menu screen to be shown

    private String selectedMapPath; // Path to the selected map file
    private boolean gameOver = false; // Flag indicating if the game is over

    /** The Sprite Batch for rendering game elements. */
    private SpriteBatch spriteBatch;

    /** The game's UI skin for styling the UI components. */
    private Skin skin;

    /** The file chooser used to load map files. */
    private final NativeFileChooser fileChooser;

    /** The game map, storing all game objects. */
    private GameMap map;

    /**
     * Constructor for BomberQuestGame.
     * @param fileChooser The file chooser for loading map files.
     */
    public BomberQuestGame(NativeFileChooser fileChooser) {
        this.fileChooser = fileChooser; // Initialize file chooser
    }

    /**
     * Called when the game is created. Initializes game resources like SpriteBatch and Skin.
     * This method serves as a second constructor after libGDX is fully initialized.
     */
    @Override
    public void create() {
        this.spriteBatch = new SpriteBatch(); // Create SpriteBatch for rendering
        this.skin = new Skin(Gdx.files.internal("skin/craftacular/craftacular-ui.json")); // Load the skin for UI components
        assetManager = new AssetManager(); // Initialize asset manager
        loadAssets(); // Load game assets (audio files)

        loadDefaultMap(); // Load the default map
        initializeGame(); // Initialize the game with the loaded map
    }

    /**
     * Loads necessary game assets like audio files.
     */
    private void loadAssets() {
        assetManager.load("audio/background.mp3", Sound.class);
        assetManager.load("audio/victory.mp3", Sound.class);
        assetManager.load("audio/explosion.mp3", Sound.class);
        assetManager.load("audio/game-over.mp3", Sound.class);
        assetManager.load("audio/powerup-pick-up.mp3", Sound.class);

        assetManager.finishLoading(); // Wait until all assets are loaded
    }

    /**
     * Loads the default map.
     */
    private void loadDefaultMap() {
        String filePath = "maps/map-1.properties"; // Default map file path
        FileHandle mapFileHandle = Gdx.files.internal(filePath);

        if (mapFileHandle.exists()) {
            File mapFile = mapFileHandle.file();
            this.map = new GameMap(this, mapFile); // Load the default map
            Gdx.app.log("BomberQuestGame", "Loaded default map from: " + mapFile.getPath());
        } else {
            Gdx.app.error("BomberQuestGame", "Default map file not found: " + filePath);
            this.map = new GameMap(this); // Fallback to an empty map
        }
    }

    /**
     * Initializes the game by playing background music and setting the game screen.
     */
    private void initializeGame() {
        if (map == null) {
            Gdx.app.error("BomberQuestGame", "Map is not loaded. Cannot initialize the game.");
            return;
        }
        MusicTrack.BACKGROUND.play(); // Play background music
        gameScreen = new GameScreen(this); // Create the game screen
        goToMenu(false); // Go to the menu screen initially
    }

    /**
     * Opens the file chooser to select a new map file.
     */
    public void loadMapFromFile() {
        NativeFileChooserConfiguration config = new NativeFileChooserConfiguration();
        config.title = "Select a Map File";
        config.directory = Gdx.files.local("."); // Open in the local directory

        fileChooser.chooseFile(config, new NativeFileChooserCallback() {
            @Override
            public void onFileChosen(FileHandle file) {
                if (file.extension().equalsIgnoreCase("properties")) { // Validate the file extension
                    Gdx.app.log("BomberQuestGame", "File chosen: " + file.path());
                    selectedMapPath = file.path(); // Store the selected file path
                } else {
                    Gdx.app.log("BomberQuestGame", "Invalid file format selected: " + file.extension());
                    selectedMapPath = null; // Reset path if invalid
                }
            }

            @Override
            public void onCancellation() {
                Gdx.app.log("BomberQuestGame", "File chooser cancelled.");
                selectedMapPath = null; // Reset path if cancelled
            }

            @Override
            public void onError(Exception exception) {
                Gdx.app.error("BomberQuestGame", "Error selecting file: " + exception.getMessage());
                selectedMapPath = null; // Reset path on error
            }
        });
    }

    /**
     * Gets the path of the selected map file.
     * @return The path to the selected map file.
     */
    public String getSelectedMapPath() {
        return selectedMapPath;
    }

    /**
     * Resets the game with a new map and reinitializes the game screen.
     * @param newMapFilePath The file path to the new map.
     */
    public void resetGame(String newMapFilePath) {
        FileHandle mapFileHandle = Gdx.files.internal(newMapFilePath);
        map = mapFileHandle.exists() ? new GameMap(this, mapFileHandle.file()) : new GameMap(this);
        gameScreen = new GameScreen(this); // Recreate the game screen
        goToGame(); // Switch to the game screen
    }

    /**
     * Switches to the menu screen.
     * @param isPaused Whether the game is paused or not.
     */
    public void goToMenu(boolean isPaused) {
        this.setScreen(new MenuScreen(this, isPaused)); // Set screen to MenuScreen
    }

    /**
     * Switches to the game screen.
     */
    public void goToGame() {
        this.setScreen(new GameScreen(this)); // Set screen to GameScreen
    }

    /**
     * Switches to the game over screen when the game is over.
     */
    public void goToGameOverScreen() {
        setGameOver(false); // Reset game over flag
        this.setScreen(new GameOverScreen(this)); // Set screen to GameOverScreen
    }

    /**
     * Sets the game over flag.
     * @param gameOver True if the game is over, false otherwise.
     */
    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver; // Set game over status
    }

    /**
     * Checks if the game is over.
     * @return True if the game is over, false otherwise.
     */
    public boolean isGameOver() {
        return gameOver;
    }

    /**
     * Returns the skin for UI elements.
     * @return The UI skin.
     */
    public Skin getSkin() {
        return skin;
    }

    /**
     * Returns the main SpriteBatch used for rendering.
     * @return The SpriteBatch instance.
     */
    public SpriteBatch getSpriteBatch() {
        return spriteBatch;
    }

    /**
     * Returns the current map of the game.
     * @return The GameMap object.
     */
    public GameMap getMap() {
        return map;
    }

    /**
     * Switches to the given screen and disposes of the previous screen.
     * @param screen The new screen.
     */
    @Override
    public void setScreen(Screen screen) {
        Screen previousScreen = super.screen;
        super.setScreen(screen);
        if (previousScreen != null) {
            previousScreen.dispose(); // Dispose of the previous screen
        }
    }

    /**
     * Returns the asset manager used to load and manage assets.
     * @return The AssetManager instance.
     */
    public AssetManager getAssetManager() {
        return assetManager;
    }

    /**
     * Disposes of the resources used by the game when the game is over.
     */
    @Override
    public void dispose() {
        getScreen().hide(); // Hide the current screen
        getScreen().dispose(); // Dispose of the current screen
        spriteBatch.dispose(); // Dispose of the sprite batch
        skin.dispose(); // Dispose of the skin
        assetManager.dispose(); // Dispose of the asset manager
    }
}
