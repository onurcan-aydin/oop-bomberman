package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.MapObject;
import de.tum.cit.ase.bomberquest.texture.Animations;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

/**
 * Represents a power-up that allows the player to place more bombs concurrently.
 * This power-up is animated and disappears once collected by the player.
 */
public class ConcurrentBombPowerup extends Powerup implements Drawable {

    /** Tracks the elapsed time for animation updates. */
    private float elapsedTime;

    /**
     * Creates a new concurrent bomb power-up at the specified coordinates.
     *
     * @param x The x-coordinate of the power-up in the game world.
     * @param y The y-coordinate of the power-up in the game world.
     */
    public ConcurrentBombPowerup(float x, float y) {
        super(x, y);
    }

    /**
     * Returns the current texture of the power-up based on animation progress.
     * The texture changes over time to create an animated effect.
     *
     * @return The appropriate frame of the animation for this power-up.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        return Animations.CONCURRENTBOMBPOWERUP.getKeyFrame(this.elapsedTime, true);
    }

    /**
     * Updates the animation timer each frame.
     *
     * @param frameTime The time elapsed since the last update, used to sync animation timing.
     */
    public void tick(float frameTime) {
        this.elapsedTime += frameTime;
    }

}
