package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.World;
import de.tum.cit.ase.bomberquest.texture.Animations;
import de.tum.cit.ase.bomberquest.texture.Drawable;

/**
 * Represents the player character in the game.
 * The player has a hitbox, so it can collide with other objects in the game.
 */
public class Player implements Drawable {

    /** Total time elapsed since the game started. Used for movement and animation. */
    private float elapsedTime;

    /** The Box2D hitbox of the player, used for position and collision detection. */
    private final Body hitbox;
    private final GameMap gameMap;
    private  int blastRadius = 1; // Initial blast radius
    private  int concurrentBombLimit = 1; // Initial bomb limit


    private enum Direction {
        UP, DOWN, LEFT, RIGHT, IDLE
    }

    private Direction currentDirection = Direction.IDLE;

    /**
     * Creates a Box2D body for the player.
     * @param world The Box2D world to add the body to.
     * @param startX The initial X position.
     * @param startY The initial Y position.
     * @return The created body.
     */
    public Player(World world, float x, float y, GameMap gameMap) {
        this.hitbox = createHitbox(world, x, y);
        this.gameMap = gameMap; // Initialize GameMap reference
    }

    /**
     * Creates the player's Box2D hitbox.
     * @param world The Box2D world.
     * @param startX The initial x-position.
     * @param startY The initial y-position.
     * @return The created body.
     */
    private Body createHitbox(World world, float startX, float startY) {
        // BodyDef defines properties for the body (position, type).
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody; // Dynamic body, affected by physics
        bodyDef.position.set(startX, startY); // Set initial position

        // Create the body in the world.
        Body body = world.createBody(bodyDef);

        // Define the player's shape (circle).
        CircleShape circle = new CircleShape();
        circle.setRadius(0.3f); // Set radius of the circle
        body.createFixture(circle, 1.0f); // Attach shape to body
        circle.dispose(); // Dispose of the shape after use

        // Set the player as the user data for this body.
        body.setUserData(this);
        return body;
    }

    /**
     * Updates player movement based on user input.
     * @param frameTime The time since the last frame.
     */
    public void tick(float frameTime) {
        this.elapsedTime += frameTime; // Update elapsed time for animation

        // Stop movement if no input is given
        if (!Gdx.input.isKeyPressed(Input.Keys.UP) &&
                !Gdx.input.isKeyPressed(Input.Keys.DOWN) &&
                !Gdx.input.isKeyPressed(Input.Keys.LEFT) &&
                !Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            this.hitbox.setLinearVelocity(0, 0); // Stop movement
            currentDirection = Direction.IDLE; // Set direction to IDLE
        }

        // Handle movement based on arrow keys
        if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
            this.hitbox.setLinearVelocity(0, 2); // Move up
            currentDirection = Direction.UP;
        } else if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            this.hitbox.setLinearVelocity(0, -2); // Move down
            currentDirection = Direction.DOWN;
        } else if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            this.hitbox.setLinearVelocity(-2, 0); // Move left
            currentDirection = Direction.LEFT;
        } else if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            this.hitbox.setLinearVelocity(2, 0); // Move right
            currentDirection = Direction.RIGHT;
        }

        // Drop bomb if spacebar is pressed
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            dropBomb();
        }

        // Collect powerups from the map
        gameMap.collectPowerupAt(this);
    }

    /**
     * Drops a bomb at the player's current location.
     */
    private void dropBomb() {
        float bombX = Math.round(getX());
        float bombY = Math.round(getY());
        gameMap.addBombToMap(bombX, bombY); // Add the bomb to the GameMap
        System.out.println("Bomb dropped at: (" + bombX + ", " + bombY + ")");
    }

    /**
     * Gets the current appearance of the player based on direction and animation state.
     * @return The texture region corresponding to the player's current direction.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        switch (currentDirection) {
            case UP:
                return Animations.CHARACTER_WALK_UP.getKeyFrame(this.elapsedTime, true);
            case DOWN:
                return Animations.CHARACTER_WALK_DOWN.getKeyFrame(this.elapsedTime, true);
            case LEFT:
                return Animations.CHARACTER_WALK_LEFT.getKeyFrame(this.elapsedTime, true);
            case RIGHT:
                return Animations.CHARACTER_WALK_RIGHT.getKeyFrame(this.elapsedTime, true);
            case IDLE:
            default:
                return Animations.CHARACTER_IDLE.getKeyFrame(this.elapsedTime, true);
        }
    }

    /**
     * Gets the current x-coordinate of the player.
     * @return The x-coordinate of the player's hitbox.
     */
    @Override
    public float getX() {
        return hitbox.getPosition().x; // Return the x-coordinate from the Box2D body
    }

    /**
     * Gets the current y-coordinate of the player.
     * @return The y-coordinate of the player's hitbox.
     */
    @Override
    public float getY() {
        return hitbox.getPosition().y; // Return the y-coordinate from the Box2D body
    }

    // Getters for blast radius and bomb limit
    public int getBlastRadius() {
        return blastRadius;
    }

    public int getConcurrentBombLimit() {
        return concurrentBombLimit;
    }

    /**
     * Resets the bomb limit to the initial value.
     */
    public void setConcurrentBombLimit() {
        this.concurrentBombLimit = 1;
    }

    /**
     * Increases the blast radius if it's less than 8.
     */
    public void increaseBlastRadius() {
        if (blastRadius < 8) {
            blastRadius++;
            System.out.println("Blast radius increased to: " + blastRadius);
            Bomb.increaseBlastRadius(blastRadius); // Update the Bomb's blast radius
        }
    }

    /**
     * Increases the concurrent bomb limit if it's less than 8.
     */
    public void increaseConcurrentBombLimit() {
        if (concurrentBombLimit < 8) {
            concurrentBombLimit++;
            System.out.println("Concurrent bomb limit increased to: " + concurrentBombLimit);
        }
    }
}
