package de.tum.cit.ase.bomberquest.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import de.tum.cit.ase.bomberquest.BomberQuestGame;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;


/**
 * Screen displayed when the player loses the game.
 * Includes a "Game Over" message, a "Return to Main Menu" button, and a "Play Again" button.
 */
public class GameOverScreen implements com.badlogic.gdx.Screen {
    private Sound loseSound; // Sound played when the player loses

    private final BomberQuestGame game; // Reference to the game
    private final Stage stage; // Stage to manage UI elements
    private final BitmapFont font; // Font for the text

    /**
     * Constructor to initialize the game over screen.
     * @param game The game instance, used to transition between screens and access resources.
     */
    public GameOverScreen(BomberQuestGame game) {
        this.game = game;

        // Set up the camera and stage for UI rendering
        OrthographicCamera camera = new OrthographicCamera();
        camera.setToOrtho(false);
        stage = new Stage(new ScreenViewport(camera), game.getSpriteBatch());
        Gdx.input.setInputProcessor(stage); // Set the input processor for handling user input

        // Set up the font for text rendering
        font = new BitmapFont(); // You can replace this with a custom font
        font.getData().setScale(2); // Scale the font
        font.setColor(Color.RED); // Set the font color to red

        // Load and play the "game over" sound
        this.loseSound = game.getAssetManager().get("audio/game-over.mp3", Sound.class);
        loseSound.play(); // Play the sound when the game ends

        // Create a layout table to organize UI elements
        Table table = new Table();
        table.setFillParent(true); // Make the table fill the screen
        stage.addActor(table); // Add the table to the stage

        // Add a "Game Over" label to the table
        Label gameOverLabel = new Label("Game Over! You Lost!", game.getSkin(), "title");
        gameOverLabel.setColor(Color.RED); // Set label color to red
        gameOverLabel.getColor().a = 0; // Start label fully transparent
        gameOverLabel.addAction(Actions.fadeIn(2f)); // Fade in the label over 2 seconds
        table.add(gameOverLabel).padBottom(40).row(); // Add the label to the table

        // Add a button to go back to the main menu
        TextButton mainMenuButton = new TextButton("Return to Main Menu", game.getSkin());
        mainMenuButton.addListener(event -> {
            if (mainMenuButton.isPressed()) {
                game.goToMenu(false); // Navigate to the main menu when the button is pressed
                return true;
            }
            return false;
        });
        table.add(mainMenuButton).width(400).padBottom(20).row(); // Add the button to the table

        // Add a button to play the game again
        TextButton playAgainButton = new TextButton("Play Again", game.getSkin());
        playAgainButton.addAction(Actions.forever(Actions.sequence(
                Actions.scaleTo(1.2f, 1.2f, 0.5f), // Scale up the button
                Actions.scaleTo(1f, 1f, 0.5f) // Scale it back down
        )));
        playAgainButton.addListener(event -> {
            if (playAgainButton.isPressed()) {
                game.goToGame(); // Restart the game when the button is pressed
                return true;
            }
            return false;
        });
        table.add(playAgainButton).width(400).row(); // Add the button to the table
    }

    /**
     * Renders the game over screen.
     * @param deltaTime The time elapsed since the last frame, used for animations.
     */
    @Override
    public void render(float deltaTime) {
        ScreenUtils.clear(Color.BLACK); // Clear the screen with a black color

        stage.act(deltaTime); // Update the stage and actors
        stage.draw(); // Draw the stage (UI elements)
    }

    /**
     * Resizes the screen viewport when the window size changes.
     * @param width The new width of the screen.
     * @param height The new height of the screen.
     */
    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true); // Update the stage viewport
    }

    @Override
    public void show() {} // Not used for this screen

    @Override
    public void hide() {} // Not used for this screen

    @Override
    public void pause() {} // Not used for this screen

    @Override
    public void resume() {} // Not used for this screen

    /**
     * Disposes of the assets when the screen is no longer needed.
     */
    @Override
    public void dispose() {
        font.dispose(); // Dispose of the font resource
    }
}
