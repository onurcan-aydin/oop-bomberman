package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

/**
 * Represents the entrance point of the game map.
 *
 * The entrance is a fixed location where the player starts when the game begins.
 */
public class Entrance implements Drawable {
    private final float x; // X-coordinate of the entrance
    private final float y; // Y-coordinate of the entrance

    /**
     * Constructs an entrance at the specified location.
     *
     * @param x The x-coordinate of the entrance.
     * @param y The y-coordinate of the entrance.
     */
    public Entrance(float x, float y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Returns the texture representing the entrance.
     *
     * @return The entrance texture.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        return Textures.ENTRANCE;
    }

    /**
     * Returns the x-coordinate of the entrance.
     *
     * @return The x-coordinate.
     */
    @Override
    public float getX() {
        return x;
    }

    /**
     * Returns the y-coordinate of the entrance.
     *
     * @return The y-coordinate.
     */
    @Override
    public float getY() {
        return y;
    }
}
