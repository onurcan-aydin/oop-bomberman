package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Disposable;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

/**
 * Represents a destructible wall in the game.
 *
 * This type of wall can be destroyed by bombs, unlike indestructible walls.
 * It also has a physics body for collision detection.
 */
public class DestructibleWall extends Wall implements Drawable, Disposable {

    /**
     * Constructs a destructible wall at the given position in the physics world.
     *
     * @param world The Box2D physics world where the wall exists.
     * @param x The x-coordinate of the wall.
     * @param y The y-coordinate of the wall.
     */
    public DestructibleWall(World world, float x, float y) {
        super(world, x, y);
    }

    /**
     * Returns the texture used to render this destructible wall.
     *
     * @return The texture region representing the destructible wall.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        return Textures.DESTRUCTIBLE_WALL;
    }

    /**
     * Destroys the physics body of the wall and removes it from the world.
     * This method ensures that the wall is properly disposed of when destroyed.
     */
    @Override
    public void dispose() {
        // Check if the body exists and belongs to a valid world before destroying it
        if (getBody() != null && getBody().getWorld() != null) {
            getBody().getWorld().destroyBody(getBody());
        }
    }
}
