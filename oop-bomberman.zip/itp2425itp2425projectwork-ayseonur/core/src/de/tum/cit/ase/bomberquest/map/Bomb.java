package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import de.tum.cit.ase.bomberquest.screen.GameScreen;
import de.tum.cit.ase.bomberquest.texture.Animations;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

/**
 * Represents a bomb in the game. The bomb has a fuse time, explodes after the timer ends,
 * and applies explosion effects within its blast radius.
 * Implements {@link Drawable} to be rendered in the game.
 */
public class Bomb implements Drawable {

    /** X-coordinate of the bomb in the game world. */
    private float x;

    /** Y-coordinate of the bomb in the game world. */
    private float y;

    /** Sound effect played when the bomb explodes. */
    private Sound explosionSound;

    /** Default blast radius for all bombs. */
    private static int blastRadius = 1;

    /** Time remaining before the bomb explodes. */
    private float fuseTime;

    /** Indicates whether the bomb has exploded. */
    private boolean exploded;

    /** Duration for which the explosion remains visible after detonation. */
    private float postExplosionTime = 1.0f;

    /** Reference to the game map, allowing the bomb to interact with game elements. */
    private final GameMap gameMap;

    /**
     * Creates a bomb at the given coordinates.
     *
     * @param x The x-coordinate of the bomb.
     * @param y The y-coordinate of the bomb.
     * @param gameMap Reference to the game map.
     */
    public Bomb(float x, float y, GameMap gameMap) {
        this.x = x;
        this.y = y;
        this.fuseTime = 3.0f; // Default fuse time (3 seconds)
        this.exploded = false;
        this.gameMap = gameMap;
        this.explosionSound = gameMap.getGame().getAssetManager().get("audio/explosion.mp3", Sound.class);
    }

    /**
     * Updates the bomb's state. Handles the countdown timer and triggers the explosion.
     *
     * @param frameTime The time elapsed since the last frame.
     */
    public void tick(float frameTime) {
        if (exploded) {
            postExplosionTime -= frameTime;

            if (postExplosionTime > 0) {
                applyExplosionEffects();
            }

            if (postExplosionTime <= 0) {
                return; // Remove the bomb after explosion animation finishes
            }
            return;
        }

        // Countdown for the bomb's fuse
        fuseTime -= frameTime;
        if (fuseTime <= 0) {
            explode();
        }
    }

    /**
     * Triggers the bomb explosion and plays the explosion sound.
     */
    private void explode() {
        exploded = true;
        explosionSound.play();
        System.out.println("Bomb exploded at: (" + x + ", " + y + ")");
        applyExplosionEffects();
    }

    /**
     * Applies the explosion effects by affecting surrounding tiles within the blast radius.
     */
    private void applyExplosionEffects() {
        // Affect the explosion center
        checkAndApplyEffects(x, y);

        // Affect surrounding tiles within the blast radius
        for (int i = 1; i <= blastRadius; i++) {
            checkAndApplyEffects(x - i, y); // Left
            checkAndApplyEffects(x + i, y); // Right
            checkAndApplyEffects(x, y + i); // Up
            checkAndApplyEffects(x, y - i); // Down
        }
    }

    /**
     * Checks and applies effects at a specific location in the game world.
     * This includes destroying walls, damaging enemies, and affecting the player.
     *
     * @param targetX The x-coordinate of the affected area.
     * @param targetY The y-coordinate of the affected area.
     */
    private void checkAndApplyEffects(float targetX, float targetY) {
        if (gameMap.isDestructibleWallAt(targetX, targetY)) {
            gameMap.destroyDestructibleWallAt(targetX, targetY);
            System.out.println("Destructible wall destroyed at: (" + targetX + ", " + targetY + ")");
        }

        if (gameMap.isEnemyAt(targetX, targetY)) {
            gameMap.destroyEnemyAt(targetX, targetY);
            System.out.println("Enemy destroyed at: (" + targetX + ", " + targetY + ")");
        }

        if (gameMap.isPlayerAt(targetX, targetY)) {
            gameMap.handlePlayerDeath();
            System.out.println("Player hit by explosion at: (" + targetX + ", " + targetY + ")");
        }
    }

    /**
     * Gets the current texture of the bomb based on its state.
     *
     * @return The bomb texture when intact, explosion texture when exploded.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        if (!exploded) {
            return Animations.BOMB.getKeyFrame(this.fuseTime, true);
        }
        return Textures.EXPLOSION_CENTER;
    }

    /**
     * Renders the bomb or its explosion effect onto the screen.
     *
     * @param spriteBatch The sprite batch used to draw the bomb.
     */
    public void render(SpriteBatch spriteBatch) {
        if (!exploded) {
            // Render bomb
            spriteBatch.draw(Animations.BOMB.getKeyFrame(this.fuseTime, true),
                    x * GameScreen.TILE_SIZE_PX * GameScreen.SCALE,
                    y * GameScreen.TILE_SIZE_PX * GameScreen.SCALE,
                    Animations.BOMB.getKeyFrame(this.fuseTime, true).getRegionWidth() * GameScreen.SCALE,
                    Animations.BOMB.getKeyFrame(this.fuseTime, true).getRegionWidth() * GameScreen.SCALE);
            return;
        }

        // Render explosion center
        spriteBatch.draw(Textures.EXPLOSION_CENTER,
                x * GameScreen.TILE_SIZE_PX * GameScreen.SCALE,
                y * GameScreen.TILE_SIZE_PX * GameScreen.SCALE,
                Textures.EXPLOSION_CENTER.getRegionWidth() * GameScreen.SCALE,
                Textures.EXPLOSION_CENTER.getRegionWidth() * GameScreen.SCALE);

        // Render explosion radius in all directions
        for (int i = 1; i <= blastRadius; i++) {
            spriteBatch.draw(i == blastRadius ? Textures.EXPLOSION_LEFT : Textures.EXPLOSION_LEFT_MID,
                    (x - i) * GameScreen.TILE_SIZE_PX * GameScreen.SCALE, y * GameScreen.TILE_SIZE_PX * GameScreen.SCALE,
                    Textures.EXPLOSION_LEFT.getRegionWidth() * GameScreen.SCALE, Textures.EXPLOSION_LEFT.getRegionWidth() * GameScreen.SCALE);

            spriteBatch.draw(i == blastRadius ? Textures.EXPLOSION_RIGHT : Textures.EXPLOSION_RIGHT_MID,
                    (x + i) * GameScreen.TILE_SIZE_PX * GameScreen.SCALE, y * GameScreen.TILE_SIZE_PX * GameScreen.SCALE,
                    Textures.EXPLOSION_RIGHT.getRegionWidth() * GameScreen.SCALE, Textures.EXPLOSION_RIGHT.getRegionWidth() * GameScreen.SCALE);

            spriteBatch.draw(i == blastRadius ? Textures.EXPLOSION_TOP : Textures.EXPLOSION_TOP_MID,
                    x * GameScreen.TILE_SIZE_PX * GameScreen.SCALE, (y + i) * GameScreen.TILE_SIZE_PX * GameScreen.SCALE,
                    Textures.EXPLOSION_TOP.getRegionWidth() * GameScreen.SCALE, Textures.EXPLOSION_TOP.getRegionWidth() * GameScreen.SCALE);

            spriteBatch.draw(i == blastRadius ? Textures.EXPLOSION_BOTTOM : Textures.EXPLOSION_BOTTOM_MID,
                    x * GameScreen.TILE_SIZE_PX * GameScreen.SCALE, (y - i) * GameScreen.TILE_SIZE_PX * GameScreen.SCALE,
                    Textures.EXPLOSION_BOTTOM.getRegionWidth() * GameScreen.SCALE, Textures.EXPLOSION_BOTTOM.getRegionWidth() * GameScreen.SCALE);
        }
    }

    /** @return Whether the bomb has exploded. */
    public boolean hasExploded() {
        return exploded;
    }

    @Override
    public float getX() {
        return x;
    }

    @Override
    public float getY() {
        return y;
    }

    /** Updates the global blast radius of all bombs. */
    public static void setBlastRadius(int newBlastRadius) {
        blastRadius = newBlastRadius;
    }

    /** Increases the global blast radius of all bombs. */
    public static void increaseBlastRadius(int newBlastRadius) {
        blastRadius = newBlastRadius;
    }

    /** @return The time remaining after the explosion. */
    public float getPostExplosionTime() {
        return postExplosionTime;
    }

    /** @return The global blast radius. */
    public static int getBlastRadius() {
        return blastRadius;
    }
}
