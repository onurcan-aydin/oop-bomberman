package de.tum.cit.ase.bomberquest.texture;

import com.badlogic.gdx.graphics.g2d.TextureRegion;

/**
 * Contains all texture constants used in the game.
 * It is good practice to keep all textures and animations in constants to avoid loading them multiple times.
 * These can be referenced anywhere they are needed.
 */
public class Textures {

    public static final TextureRegion FLOWERS = SpriteSheet.BASIC_TILES.at(2, 5);
    public static final TextureRegion BLAST_RADIUS_POWERUP = SpriteSheet.OBJECTS.at(4, 5);
    public static final TextureRegion CHEST = SpriteSheet.BASIC_TILES.at(5, 5);
    public static final TextureRegion CONCURRENT_BOMB_POWERUP = SpriteSheet.THINGS.at(7, 4);
    public static final TextureRegion INDESTRUCTIBLE_WALL = SpriteSheet.THINGS.at(1, 4);
    public static final TextureRegion DESTRUCTIBLE_WALL = SpriteSheet.BASIC_TILES.at(12, 1);
    public static final TextureRegion ENEMY = SpriteSheet.MOBS.at(1, 2);
    public static final TextureRegion ENTRANCE = SpriteSheet.BASIC_TILES.at(7, 1);
    public static final TextureRegion EXIT = SpriteSheet.BASIC_TILES.at(4, 8);
    //public static final TextureRegion BOMB = SpriteSheet.ORIGINAL_BOMBERMAN.at(4, 1);

    // Explosion textures for radius 1
    public static final TextureRegion EXPLOSION_CENTER = SpriteSheet.ORIGINAL_BOMBERMAN.at(7, 3); // Center
    public static final TextureRegion EXPLOSION_LEFT = SpriteSheet.ORIGINAL_BOMBERMAN.at(7, 1); // Left
    public static final TextureRegion EXPLOSION_RIGHT = SpriteSheet.ORIGINAL_BOMBERMAN.at(7, 5); // Right
    public static final TextureRegion EXPLOSION_TOP = SpriteSheet.ORIGINAL_BOMBERMAN.at(5, 3); // Top
    public static final TextureRegion EXPLOSION_BOTTOM = SpriteSheet.ORIGINAL_BOMBERMAN.at(9, 3); // Bottom

    // Explosion textures for radius 3 (extends radius 1)
    public static final TextureRegion EXPLOSION_LEFT_MID = SpriteSheet.ORIGINAL_BOMBERMAN.at(7, 2); // Middle parts for Left
    public static final TextureRegion EXPLOSION_RIGHT_MID = SpriteSheet.ORIGINAL_BOMBERMAN.at(7, 4); // Middle parts for Right
    public static final TextureRegion EXPLOSION_TOP_MID = SpriteSheet.ORIGINAL_BOMBERMAN.at(6, 3); // Middle parts for Top
    public static final TextureRegion EXPLOSION_BOTTOM_MID = SpriteSheet.ORIGINAL_BOMBERMAN.at(8, 3); // Middle parts for Bottom

}
