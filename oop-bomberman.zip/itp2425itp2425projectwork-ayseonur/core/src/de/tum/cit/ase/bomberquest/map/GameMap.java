package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Box2D;
import com.badlogic.gdx.physics.box2d.World;
import de.tum.cit.ase.bomberquest.BomberQuestGame;
import de.tum.cit.ase.bomberquest.screen.GameOverScreen;
import de.tum.cit.ase.bomberquest.screen.Hud;
import de.tum.cit.ase.bomberquest.screen.VictoryScreen;

import java.io.*;
import java.util.*;

/**
 * Represents the game map.
 * Holds all the objects and entities in the game.
 */
public class GameMap {

    // A static block is executed once when the class is referenced for the first time.
    static {
        // Initialize the Box2D physics engine.
        Box2D.init();
    }

    // Box2D physics simulation parameters (you can experiment with these if you want, but they work well as they are)
    /**
     * The time step for the physics simulation.
     * This is the amount of time that the physics simulation advances by in each frame.
     * It is set to 1/refreshRate, where refreshRate is the refresh rate of the monitor, e.g., 1/60 for 60 Hz.
     */
    private static final float TIME_STEP = 1f / Gdx.graphics.getDisplayMode().refreshRate;
    /** The number of velocity iterations for the physics simulation. */
    private static final int VELOCITY_ITERATIONS = 6;
    /** The number of position iterations for the physics simulation. */
    private static final int POSITION_ITERATIONS = 2;
    /**
     * The accumulated time since the last physics step.
     * We use this to keep the physics simulation at a constant rate even if the frame rate is variable.
     */
    private float physicsTime = 0;

    /** The game, in case the map needs to access it. */
    private final BomberQuestGame game;
    /** The Box2D world for physics simulation. */
    private final World world;

    private int mapWidth = 0; // Maximum x-coordinate from the map file
    private int mapHeight = 0; // Maximum y-coordinate from the map file

    // Game objects
    private final Player player;

    //private final Chest chest;

    private final Flowers[][] flowers;
    private final List<DestructibleWall> destructibleWalls;
    private final List<IndestructibleWall> inDestructibleWalls;
    private  List<Enemy> enemies;
    private Entrance entrance; // we need at least one entrance and one exit
    private Exit exit;
    private final List<ConcurrentBombPowerup> concurrentPowerups;
    private final List<BlastRadiusPowerup> blastRadiusPowerups;
    private List<Bomb> bombs;
    private HashMap<Vector2, Integer> objects;

    private Hud hud;

    public GameMap(BomberQuestGame game) {
        this.game = game;
        this.world = new World(Vector2.Zero, true);
        // Create a player with initial position (1, 3)
        this.player = new Player(this.world, 1, 3,this);
        // Create flowers in a 7x7 grid
        this.flowers = new Flowers[7][7];
        for (int i = 0; i < flowers.length; i++) {
            for (int j = 0; j < flowers[i].length; j++) {
                this.flowers[i][j] = new Flowers(i, j);
            }
        }
        this.destructibleWalls = new ArrayList<>();
        this.inDestructibleWalls = new ArrayList<>();
        this.enemies = new ArrayList<>();
        this.concurrentPowerups = new ArrayList<>();
        this.blastRadiusPowerups = new ArrayList<>();
        this.bombs=new ArrayList<>();

    }
    public GameMap(BomberQuestGame game, File mapFile) {
        this.game = game;
        this.world = new World(Vector2.Zero, true);
        this.objects = new HashMap<>();
        loadMap(mapFile);


        this.destructibleWalls = new ArrayList<>();
        this.inDestructibleWalls = new ArrayList<>();
        this.enemies = new ArrayList<>();
        this.concurrentPowerups = new ArrayList<>();
        this.blastRadiusPowerups = new ArrayList<>();
        this.bombs=new ArrayList<>();



        this.flowers = new Flowers[mapHeight][mapWidth];
        for (int i = 0; i < flowers.length; i++) {
            for (int j = 0; j < flowers[i].length; j++) {
                this.flowers[i][j] = new Flowers(i, j);
            }
        }
        for (Map.Entry<Vector2, Integer> entry : objects.entrySet()) {
            Vector2 key = entry.getKey();  // The coordinate
            Integer value = entry.getValue();  // The type

            if (value == 1){
                this.destructibleWalls.add(new DestructibleWall(this.world, key.x, key.y));
            }
            else if (value == 0){
                this.inDestructibleWalls.add(new IndestructibleWall(this.world, key.x, key.y));
            }
            else if (value == 2){
                this.entrance = new Entrance(key.x, key.y);
            }
            else if (value == 3){
                this.enemies.add(new Enemy(key.x, key.y));
            }
            else if (value == 4){
                this.exit = new Exit(key.x, key.y);
                this.destructibleWalls.add(new DestructibleWall(this.world, key.x, key.y));
            }
            else if (value == 5){
                this.concurrentPowerups.add(new ConcurrentBombPowerup(key.x, key.y));
            }
            else if (value == 6){
                this.blastRadiusPowerups.add(new BlastRadiusPowerup(key.x, key.y));
                this.destructibleWalls.add(new DestructibleWall(this.world, key.x, key.y));
            }

            ensureExitExists();
        }
        // Player's initial location is the entrance's location
        this.player = new Player(this.world, entrance.getX(), entrance.getY(),this);


    }
    //private Map<Vector2, Integer> loadMap(File mapFile) {
    private void loadMap(File mapFile) {

        try (BufferedReader reader = new BufferedReader(new FileReader(mapFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();

                // Skip empty lines and comments
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }

                // Split the line into key (coordinates) and value (type)
                String[] parts = line.split("=");
                if (parts.length != 2) {
                    continue; // Skip malformed lines
                }

                // Split the key into x and y coordinates
                String[] coordinates = parts[0].split(",");
                if (coordinates.length != 2) {
                    continue; // Skip malformed keys
                }

                try {
                    int x = Integer.parseInt(coordinates[0]);
                    int y = Integer.parseInt(coordinates[1]);
                    int type = Integer.parseInt(parts[1]);

                    // Add the object to the map
                    objects.put(new Vector2(x, y), type);
                    // Update mapWidth and mapHeight
                    mapWidth = Math.max(mapWidth, x + 1); // Add 1 because coordinates start at 0
                    System.out.println("LOAD MAP");
                    System.out.println("Map width: " + mapWidth);

                    mapHeight = Math.max(mapHeight, y + 1); // Add 1 because coordinates start at 0
                    System.out.println("Map height: " + mapHeight);

                } catch (NumberFormatException e) {
                    // Skip lines with invalid numbers
                    System.err.println("Invalid line in map file: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // return objects;
    }


    /**
     * Ensures an exit exists on the map. If no exit is specified, places it under a random destructible wall.
     */
    private void ensureExitExists() {
        boolean exitExists = objects.containsValue(4);

        if (!exitExists) {
            // Collect all destructible wall positions
            List<Vector2> destructibleWalls = new ArrayList<>();
            for (Map.Entry<Vector2, Integer> entry : objects.entrySet()) {
                if (entry.getValue() == 1) { // Type 1 is a destructible wall
                    destructibleWalls.add(entry.getKey());
                }
            }

            // Randomly pick one destructible wall to place the exit
            if (!destructibleWalls.isEmpty()) {
                Random random = new Random();
                Vector2 chosenPosition = destructibleWalls.get(random.nextInt(destructibleWalls.size()));

                // Place the exit and update the map
                objects.put(chosenPosition, 4); // Type 4 is an exit
                exit = new Exit(chosenPosition.x, chosenPosition.y);

                System.out.println("Exit added at: " + chosenPosition);
            }
        }
    }

    /**
     * Updates the game state. This is called once per frame.
     * Every dynamic object in the game should update its state here.
     * @param frameTime the time that has passed since the last update
     */
    public void tick(float frameTime) {
        this.player.tick(frameTime);
        for (int i = 0; i < concurrentPowerups.size(); i++){
            this.concurrentPowerups.get(i).tick(frameTime);

        }

        for (int i = 0; i < blastRadiusPowerups.size(); i++){
            this.blastRadiusPowerups.get(i).tick(frameTime);

        }


        // Check if the exit is unlocked and the player reaches it
        if (isExitAt(player.getX(), player.getY())) {
            if (enemies.isEmpty()) {
                handlePlayerWin(); // Win the game if all enemies are defeated
            } else {
                System.out.println("The exit is locked! Defeat all enemies first.");
            }
        }

        // Update enemies and check for collisions
        for (Enemy enemy : enemies) {
            enemy.tick(frameTime, this);

            // Check if the player collides with the enemy
            if (enemy.collidesWithPlayer(this.player)) {
                System.out.println("Player collided with an enemy!");
                handlePlayerDeath(); // End the game if there's a collision
                return; // Stop further processing once the game ends
            }
        }


        // Update bombs
        List<Bomb> bombsToRemove = new ArrayList<>();
        for (Bomb bomb : bombs) {
            bomb.tick(frameTime);
            // Check if the bomb explosion duration is over
            if (bomb.hasExploded() && bomb.getPostExplosionTime() <= 0) {
                bombsToRemove.add(bomb); // Mark bomb for removal
            }
        }

        // Remove exploded bombs from the map
        bombs.removeAll(bombsToRemove);
        doPhysicsStep(frameTime);
    }


    public boolean isExitAt(float x, float y) {
        return Math.round(exit.getX()) == Math.round(x) && Math.round(exit.getY()) == Math.round(y);
    }

    /**
     * Performs as many physics steps as necessary to catch up to the given frame time.
     * This will update the Box2D world by the given time step.
     * @param frameTime Time since last frame in seconds
     */
    private void doPhysicsStep(float frameTime) {
        this.physicsTime += frameTime;
        while (this.physicsTime >= TIME_STEP) {
            this.world.step(TIME_STEP, VELOCITY_ITERATIONS, POSITION_ITERATIONS);
            this.physicsTime -= TIME_STEP;
        }
    }
    public void addBombToMap(float x, float y) {
        //Bomb bomb = new Bomb(x, y,1,this);
        Bomb bomb = new Bomb(x, y, this);

        if(this.bombs.size()<player.getConcurrentBombLimit()) {
            this.bombs.add(bomb);
        }
        // we should check if it has powerup, later
        System.out.println("Bomb added at: (" + x + ", " + y + ")");
    }
    /** Returns the player on the map. */
    public Player getPlayer() {
        return player;
    }

    /** Returns the chest on the map. */
    //public Chest getChest() {
    //    return chest;
    //}

    /** Returns the flowers on the map. */
    public List<Flowers> getFlowers() {
        return Arrays.stream(flowers).flatMap(Arrays::stream).toList();
    }
    public List<DestructibleWall> getDestructibleWalls() {
        return destructibleWalls;
    }
    public List<IndestructibleWall> getInDestructibleWalls() {
        return inDestructibleWalls;
    }
    public List<Enemy> getEnemies() {
        return enemies;
    }
    public List<ConcurrentBombPowerup> getConcurrentPowerups() {
        return concurrentPowerups;
    }
    public List<BlastRadiusPowerup> getBlastRadiusPowerups() {
        return blastRadiusPowerups;
    }
    public List<Bomb> getBombs(){return bombs;}
    public Entrance getEntrance(){
        return entrance;
    }

    public Exit getExit(){
        return exit;
    }

    public int getWidth() {
        return mapWidth;
    }

    public int getHeight() {
        return mapHeight;
    }

    public boolean isIndestructibleWallAt(float x, float y) {
        return inDestructibleWalls.stream().anyMatch(wall -> wall.getX() == x && wall.getY() == y);
    }

    public boolean isDestructibleWallAt(float x, float y) {
        return destructibleWalls.stream().anyMatch(wall -> wall.getX() == x && wall.getY() == y);
    }

    public void destroyDestructibleWallAt(float x, float y) {

        System.out.println("Attempting to destroy wall at: (" + x + ", " + y + ")");
        Iterator<DestructibleWall> iterator = destructibleWalls.iterator();
        while (iterator.hasNext()) {
            DestructibleWall wall = iterator.next();
            //System.out.println("Checking wall at: (" + wall.getX() + ", " + wall.getY() + ")");

            if (Math.round(wall.getX()) == Math.round(x) && Math.round(wall.getY()) == Math.round(y)) {
                wall.dispose();
                //wall.destroyBody(world); // Remove the physics body from the world
                iterator.remove(); // Remove the wall from the list
                //System.out.println("Destroyed wall at: (" + x + ", " + y + ")");

                //System.out.println("Destroyed wall at: (" + x + ", " + y + ")");
                return;
            }
        }
        //System.out.println("No destructible wall found at: (" + x + ", " + y + ")");
    }

    public void collectPowerupAt(Player player) {
        float playerX = Math.round(player.getX());
        float playerY = Math.round(player.getY());

        // Check for concurrent bomb power-ups
        Iterator<ConcurrentBombPowerup> concurrentIterator = concurrentPowerups.iterator();
        while (concurrentIterator.hasNext()) {
            ConcurrentBombPowerup powerup = concurrentIterator.next();
            if (Math.round(powerup.getX()) == playerX && Math.round(powerup.getY()) == playerY) {
                Sound powerupSound = game.getAssetManager().get("audio/powerup-pick-up.mp3", Sound.class);
                powerupSound.play();

                player.increaseConcurrentBombLimit();
                concurrentIterator.remove();
                System.out.println("Collected a concurrent bomb power-up!");
            }
        }

        // Check for blast radius power-ups
        Iterator<BlastRadiusPowerup> radiusIterator = blastRadiusPowerups.iterator();
        while (radiusIterator.hasNext()) {
            BlastRadiusPowerup powerup = radiusIterator.next();
            if (Math.round(powerup.getX()) == playerX && Math.round(powerup.getY()) == playerY) {
                Sound powerupSound = game.getAssetManager().get("audio/powerup-pick-up.mp3", Sound.class);
                powerupSound.play();

                player.increaseBlastRadius();
                radiusIterator.remove();
                System.out.println("Collected a blast radius power-up!");
            }
        }
    }

    public boolean isEntityAt(float x, float y) {
        return enemies.stream().anyMatch(enemy -> enemy.getX() == x && enemy.getY() == y)
                || player.getX() == x && player.getY() == y;
    }

    public void destroyEntityAt(float x, float y) {
        enemies.removeIf(enemy -> enemy.getX() == x && enemy.getY() == y);
        //if (hud != null) {
        //    hud.setRemainingEnemies(enemies.size());
        //}
        if (player.getX() == x && player.getY() == y) {
            System.out.println("Player hit by blast at: (" + x + ", " + y + ")");
            // Handle player death logic
        }
        System.out.println("Destroyed entity at: (" + x + ", " + y + ")");
    }
    public boolean isPlayerAt(float x, float y) {
        return Math.round(player.getX()) == Math.round(x) && Math.round(player.getY()) == Math.round(y);
    }

    public boolean isEnemyAt(float x, float y) {
        // Iterate through the list of enemies
        for (Enemy enemy : enemies) {
            // Check if the enemy's position matches the given coordinates (rounded for grid alignment)
            if (Math.round(enemy.getX()) == Math.round(x) && Math.round(enemy.getY()) == Math.round(y)) {
                return true; // An enemy is at the specified position
            }
        }
        return false; // No enemy at the specified position
    }
    //public void destroyEnemyAt(float x, float y) {
    //    Iterator<Enemy> iterator = enemies.iterator();
    //    while (iterator.hasNext()) {
    //        Enemy enemy = iterator.next();
    //        if (Math.round(enemy.getX()) == Math.round(x) && Math.round(enemy.getY()) == Math.round(y)) {
    //            iterator.remove(); // Remove the enemy from the list
    //            System.out.println("Enemy killed at: (" + x + ", " + y + ")");
    //            // Notify the HUD of the updated enemy count
    //            if (hud != null) {
    //                hud.setRemainingEnemies(enemies.size());
    //                System.out.println("Remaining enemies: " + enemies.size());
    //            }
    //            return;
    //        }
    //    }
    //    System.out.println("No enemy found at: (" + x + ", " + y + ")");
    //}

    public void destroyEnemyAt(float x, float y) {
        Iterator<Enemy> iterator = enemies.iterator();
        while (iterator.hasNext()) {
            Enemy enemy = iterator.next();
            if (isCloseEnough(enemy.getX(), x) && isCloseEnough(enemy.getY(), y)) {
                iterator.remove(); // Remove the enemy from the list
                System.out.println("Enemy killed at: (" + x + ", " + y + ")");


                // Notify the HUD of the updated enemy count
                if (hud != null) {
                    hud.setRemainingEnemies(enemies.size());
                    System.out.println("Remaining enemies: " + enemies.size());
                }
                return;
            }
        }
        System.out.println("No enemy found at: (" + x + ", " + y + ")");
    }


    private boolean isCloseEnough(float a, float b) {
        return Math.abs(a - b) < 0.1f; // Adjust the threshold as needed
    }

    // Add power-ups to the map (example usage)
    public void addConcurrentBombPowerup(float x, float y) {
        concurrentPowerups.add(new ConcurrentBombPowerup(x, y));
    }

    public void addBlastRadiusPowerup(float x, float y) {
        blastRadiusPowerups.add(new BlastRadiusPowerup(x, y));
    }

    public void handleCountdownEnd() {
        System.out.println("Countdown ended! Game is over.");
        // Oyunu sonlandırma veya yeniden başlatma işlemleri

        game.goToMenu(false);
        game.create();
        Bomb.setBlastRadius(1);
        this.player.setConcurrentBombLimit();
    }

    public void handlePlayerDeath() {
        System.out.println("Player is dead! Game is over.");
        // Oyunu sonlandırma veya yeniden başlatma işlemleri
        game.create();
        game.setScreen(new GameOverScreen(game));
        Bomb.setBlastRadius(1);
        this.player.setConcurrentBombLimit();
    }
    public void handlePlayerWin() {
        System.out.println("Player reached the exit! You win!");
        // Handle the logic for winning the game (e.g., show a win screen, restart, etc.)
        game.setScreen(new VictoryScreen(game)); // Switch to the VictoryScreen

    }


    public void setHud(Hud hud) {
        this.hud = hud;
    }

    public BomberQuestGame getGame() {
        return this.game;
    }
}
