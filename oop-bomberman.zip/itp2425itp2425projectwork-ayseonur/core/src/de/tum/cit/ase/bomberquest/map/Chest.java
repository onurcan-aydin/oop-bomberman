package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.*;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

/**
 * Represents a static chest object in the game.
 * The chest acts as a solid object that the player cannot pass through.
 * It has a hitbox for collision detection but does not move.
 */
public class Chest implements Drawable {

    /** The x-coordinate of the chest in the game world. */
    private final float x;

    /** The y-coordinate of the chest in the game world. */
    private final float y;

    /**
     * Creates a chest at the given position in the game world.
     *
     * @param world The Box2D world where the chest's hitbox will be added.
     * @param x The x-coordinate of the chest.
     * @param y The y-coordinate of the chest.
     */
    public Chest(World world, float x, float y) {
        this.x = x;
        this.y = y;
        createHitbox(world);
    }

    /**
     * Creates a Box2D hitbox for the chest.
     * Since the chest is a static object, it will not move, but other entities can collide with it.
     *
     * @param world The Box2D world where the hitbox will be registered.
     */
    private void createHitbox(World world) {
        // Define the properties of the body.
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.StaticBody; // Static bodies do not move.
        bodyDef.position.set(this.x, this.y); // Set the position of the chest.

        // Create the body in the physics world.
        Body body = world.createBody(bodyDef);

        // Define the shape of the chest's hitbox.
        PolygonShape box = new PolygonShape();
        box.setAsBox(0.5f, 0.5f); // Define a square shape (1 tile in size).

        // Attach the shape to the body.
        body.createFixture(box, 1.0f);

        // Dispose of the shape to free up memory.
        box.dispose();

        // Set the chest object as the user data of the body, allowing it to be identified during collisions.
        body.setUserData(this);
    }

    /**
     * Returns the texture of the chest.
     *
     * @return The texture region representing the chest.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        return Textures.CHEST;
    }

    /** @return The x-coordinate of the chest. */
    @Override
    public float getX() {
        return x;
    }

    /** @return The y-coordinate of the chest. */
    @Override
    public float getY() {
        return y;
    }
}
