package de.tum.cit.ase.bomberquest.map;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import de.tum.cit.ase.bomberquest.texture.Drawable;
import de.tum.cit.ase.bomberquest.texture.Textures;

/**
 * Represents a decorative flower tile in the game map.
 *
 * Flowers are purely aesthetic and do not affect gameplay.
 * They do not have a hitbox, meaning the player and other entities can walk over them freely.
 */
public class Flowers implements Drawable {

    private final float x; // X-coordinate of the flower
    private final float y; // Y-coordinate of the flower

    /**
     * Creates a flower at the given position.
     *
     * @param x The x-coordinate of the flower.
     * @param y The y-coordinate of the flower.
     */
    public Flowers(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Returns the texture of the flower.
     *
     * @return The texture representing the flower.
     */
    @Override
    public TextureRegion getCurrentAppearance() {
        return Textures.FLOWERS;
    }

    /**
     * Returns the x-coordinate of the flower.
     *
     * @return The x-coordinate.
     */
    @Override
    public float getX() {
        return x;
    }

    /**
     * Returns the y-coordinate of the flower.
     *
     * @return The y-coordinate.
     */
    @Override
    public float getY() {
        return y;
    }
}
