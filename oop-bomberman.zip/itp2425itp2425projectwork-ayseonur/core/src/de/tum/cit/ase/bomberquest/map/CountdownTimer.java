package de.tum.cit.ase.bomberquest.map;

/**
 * A simple countdown timer used to track time in the game.
 * The timer starts running when initialized and can be paused, resumed, or reset.
 * It triggers an event when time reaches zero.
 */
public class CountdownTimer {

    /** The amount of time left before the timer reaches zero, in seconds. */
    private float timeRemaining;

    /** A flag indicating whether the timer is currently running. */
    private boolean isRunning;

    /** A listener that is notified when the timer runs out. */
    private TimerListener listener;

    /**
     * Creates a new countdown timer with a specified starting time.
     *
     * @param initialTime The initial countdown time in seconds.
     */
    public CountdownTimer(float initialTime) {
        this.timeRemaining = initialTime;
        this.isRunning = true; // Timer starts running immediately
    }

    /**
     * Updates the timer based on the time passed since the last frame.
     * If the timer reaches zero, it stops and notifies the listener.
     *
     * @param deltaTime The time elapsed since the last frame, in seconds.
     */
    public void update(float deltaTime) {
        if (isRunning) {
            timeRemaining -= deltaTime;
            if (timeRemaining <= 0) {
                timeRemaining = 0;
                isRunning = false;
                if (listener != null) {
                    listener.onTimeUp(); // Notify listener that time has run out
                }
            }
        }
    }

    /**
     * Adds extra time to the countdown.
     *
     * @param extraTime The amount of time to add, in seconds.
     */
    public void addTime(float extraTime) {
        timeRemaining += extraTime;
    }

    /**
     * Pauses the timer, stopping it from counting down.
     */
    public void pause() {
        isRunning = false;
    }

    /**
     * Resumes the timer, allowing it to continue counting down.
     */
    public void resume() {
        isRunning = true;
    }

    /**
     * Resets the timer to a new specified time and starts it.
     *
     * @param newTime The new countdown time in seconds.
     */
    public void reset(float newTime) {
        this.timeRemaining = newTime;
        this.isRunning = true;
    }

    /**
     * Gets the remaining time in seconds.
     *
     * @return The time left on the countdown timer.
     */
    public float getTimeRemaining() {
        return timeRemaining;
    }

    /**
     * Sets a listener for the timer event when time reaches zero.
     *
     * @param listener The TimerListener implementation that will handle the event.
     */
    public void setListener(TimerListener listener) {
        this.listener = listener;
    }

    /**
     * Interface for handling timer-related events.
     * Classes implementing this interface must define what happens when time runs out.
     */
    public interface TimerListener {
        /**
         * This method is triggered when the timer reaches zero.
         */
        void onTimeUp();
    }
}
